﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Dictonary
{
    class Program
    {
        static void Main(string[] args)
        {
            // Assignment 1
            Contact obj1 = new Contact() { ID = 1, Name = "Pooja", City = "Satara", ContactNo = 12345 };
            Contact obj6 = new Contact() { ID = 6, Name = "Pragnesha", City = "Satara", ContactNo = 12345 };
            Contact obj2 = new Contact() { ID = 2, Name = "Priti", City = "Pune", ContactNo = 2345 };
            Contact obj3 = new Contact() { ID = 3, Name = "Radha", City = "Mumbai", ContactNo = 3456 };
            Contact obj4 = new Contact() { ID = 4, Name = "Kushi", City = "Nashik", ContactNo = 4567 };
            Contact obj5 = new Contact() { ID = 5, Name = "Seema", City = "Banglore", ContactNo = 5678 };

            Dictionary<int, Contact> ContactList = new Dictionary<int, Contact>();
            ContactList.Add(1, obj1);
            ContactList.Add(2, obj2);
            ContactList.Add(3, obj3);
            ContactList.Add(4, obj4);
            ContactList.Add(5, obj5);
            ContactList.Add(6, obj6);


            var forSerachBYID = ContactList.Where(x => x.Value.ID == 1).FirstOrDefault();
            var forSerachBYName = ContactList.Where(x => x.Value.Name.Equals("Kushi")).ToList();

            Console.WriteLine($" Search BY ID ( : ID :  {forSerachBYID.Key.ToString()}, Name : {forSerachBYID.Value.Name} )");

            foreach (var item in forSerachBYName)
            {
                Console.WriteLine($" Search BY Name ( : ID :  {item.Key.ToString()}, Name : {item.Value.Name} )");
            }

            List<Contact> Contacts = new List<Contact>() { obj1, obj2, obj3, obj4, obj5 };

            var c = Contacts.Where(x => x.ID == 1).FirstOrDefault();
            c.Name = "Nikita";

            foreach (var item in Contacts)
            {
                Console.WriteLine($"ID : {item.ID}, Name : {item.Name}, city : {item.City}, ContactNo : {item.ContactNo}");
            }

            //Assignment 2

            List<Contact> Users = new List<Contact>
            {
                new Contact() { ID = 1, Name = "Pooja", City = "Satara", ContactNo = 12345 },
                new Contact() { ID = 6, Name = "Pragnesha", City = "Satara", ContactNo = 12345 },
                new Contact() { ID = 2, Name = "Priti", City = "Pune", ContactNo = 2345 },
                new Contact() { ID = 3, Name = "Radha", City = "Mumbai", ContactNo = 3456 },
                new Contact() { ID = 4, Name = "Kushi", City = "Nashik", ContactNo = 4567 },
                new Contact() { ID = 5, Name = "Seema", City = "Banglore", ContactNo = 5678 }
            };

            Console.WriteLine("**********************************************");

            foreach (var item in Users)
            {
                Console.WriteLine($"ID : {item.ID}, Name : {item.Name}, city : {item.City}, CellNo : {item.ContactNo}");
            }

            var byID = Users.Where(x => x.ID == 1).FirstOrDefault();
            var byName = Users.Where(x => x.Name.Equals("Kushi")).ToList();

            Console.WriteLine($" Search BY ID ( : ID :  {byID.ID.ToString()}, Name : {byID.Name} )");

            foreach (var item in byName)
            {
                Console.WriteLine($" Search BY Name ( : ID :  {item.ID.ToString()}, Name : {item.Name} )");
            }

            Console.ReadKey();
        }
    }
}
