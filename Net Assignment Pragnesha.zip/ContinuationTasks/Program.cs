﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ContinuationTasks
{
    class Program
    {
        static void Main(string[] args)
        {
            Task<int> total = Task.Run(() => Total(10, 20, 30));
            total.ContinueWith((avg) => {
                Console.WriteLine("Total=" + avg.Result);
                Console.WriteLine("Average=" + Avg(avg.Result, 3));
                }
            );
            Console.ReadKey();
        }
        static int Total(int a,int b,int c) {

            return a + b + c;
        }
        static int Avg(int a1,int b1)
        {
            return (a1 / b1);
        }
    }
}
