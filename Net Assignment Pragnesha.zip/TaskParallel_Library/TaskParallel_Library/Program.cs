﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Threading;
using System.IO;

namespace TaskParallel_Library
{
    class Program
    {
        static void Main(string[] args)
        {
            Task<string> task = GetSomeData();
            Console.WriteLine(task.Result);
            Console.ReadKey();
        }
        
            static async Task<string> GetSomeData()
        {
            Thread.Sleep(5000);
            string t1 = "GetSomeDataTask";
            return t1;
        }
    }
    
}
