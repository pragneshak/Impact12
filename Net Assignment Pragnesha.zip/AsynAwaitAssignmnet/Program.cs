﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace AsynAwaitAssignmnet
{
    class Program
    {
        static void Main(string[] args)
        {
            Task t1 = new Task(CallMethod);
            t1.Start();
            Console.ReadKey();
        }
        static async void CallMethod()
        {
            Task<string> task = GetVideo();
          //  Console.WriteLine(task.Result);
            string video = await task;
            Task<string> intro = AddIntro(video);
            string introvideo = await intro;
            Task<string> final= AddSummary(introvideo);
            Console.WriteLine(final.Result);

        }
        static async Task<string> GetVideo(){
            Thread.Sleep(10000);
            string t1 = "Get Video";
            return t1;
        }
        static async Task<string> AddIntro(string video){
            Thread.Sleep(20000);
            string t1 = "Introduction of Video " + video ;
            return t1;
        }
        static async Task<string> AddSummary(string video)
        {
            Thread.Sleep(30000);
            string t1 = video + " Summary of Video";
            return t1;

        }
    }
}
