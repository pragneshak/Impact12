﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MulticastDelegate
{
    public class ListOfOrders
    {
        public List<CustomerOrder> OrderList;

        public event Action<List<CustomerOrder>> PrintNoOfOrdersRecieved;
        public event Action<List<CustomerOrder>> PrintTotalNoOfOrdersRecieved;

        public ListOfOrders()
        {
            OrderList = new List<CustomerOrder>();
        }


        public void addCustomerOrder(CustomerOrder orderdetail)
        {
            OrderList.Add(orderdetail);

            PrintNoOfOrdersRecieved?.Invoke(this.OrderList);
            PrintTotalNoOfOrdersRecieved?.Invoke(this.OrderList);
        }

        public CustomerOrder SearchByID(int id)
        {
            var order1 = (from order in OrderList
                          where order.orderid == id
                          select new
                          {
                              order.orderid,
                              order.custname,
                              order.disapatchcity,
                              order.orderamount,
                              order.orderdate
                          }).FirstOrDefault();

            CustomerOrder data = new CustomerOrder();
            data.orderid = order1.orderid;
            data.orderdate = order1.orderdate;
            data.custname = order1.custname;
            data.disapatchcity = order1.disapatchcity;
            data.orderamount = order1.orderamount;

            return data;
        }

        public List<CustomerOrder> SearchByName(string name)
        {
            return this.OrderList.Where(x => x.custname.Equals(name)).ToList();
        }
        
        public List<CustomerOrder> SearchByDispatchCity(string cityname)
        {
            return this.OrderList.Where(x => x.disapatchcity.Equals(cityname)).ToList();
        }
    }
}
