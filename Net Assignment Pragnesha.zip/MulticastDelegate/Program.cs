﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MulticastDelegate
{
    class Program
    {
        public static void printnooforders(List<CustomerOrder> data)
        {
            Console.WriteLine($"No of Orders till now is : {data.Count}");
        }

        public static void printTotalNoOforders(List<CustomerOrder> data)
        {
            Console.WriteLine($"Total No of Orders till now is : {data.Count}");
        }

        public static void Print(CustomerOrder item)
        {
           
            Console.WriteLine($"OrderID = {item.orderid}, CustomerName = {item.custname}, OrderDate = {item.orderdate}, city = {item.disapatchcity}, amount = {item.orderamount}");
          
        }

        static void Main(string[] args)
        {
            ListOfOrders listororder = new ListOfOrders();

            listororder.PrintNoOfOrdersRecieved += printnooforders;
            listororder.PrintNoOfOrdersRecieved += printTotalNoOforders;

            listororder.addCustomerOrder(new CustomerOrder()
            {
                orderid = 1,
                custname = "Pragnesha",
                orderdate = DateTime.Now,
                orderamount = 123.33,
                disapatchcity = "Mumbai"
            });


            listororder.addCustomerOrder(new CustomerOrder()
            {
                orderid = 2,
                custname = "Nikita",
                orderdate = DateTime.Now,
                orderamount = 123.33,
                disapatchcity = "Aurangabad"
            });

            listororder.addCustomerOrder(new CustomerOrder()
            {
                orderid = 3,
                custname = "Chaitanya",
                orderdate = DateTime.Now,
                orderamount = 123.33,
                disapatchcity = "Pune"


            });

            listororder.addCustomerOrder(new CustomerOrder()
            {
                orderid = 4,
                custname = "Piyush",
                orderdate = DateTime.Now,
                orderamount = 123.33,
                disapatchcity = "Baner"
            });

            listororder.addCustomerOrder(new CustomerOrder()
            {
                orderid = 5,
                custname = "Nikhil",
                orderdate = DateTime.Now,
                orderamount = 1000.23,
                disapatchcity = "Latur"
            });



            Print(listororder.SearchByID(1));

            Console.WriteLine();

            var printmulti = listororder.SearchByName("Pragnesha");
            foreach (var item in printmulti)
            {
                Print(item);
            }

            Console.WriteLine();

            var printmulticity = listororder.SearchByDispatchCity("Baner");
            foreach (var item in printmulticity)
            {
                Print(item);
            }



            //      Question 5

            List<CustOrder> custorder = new List<CustOrder>();

            bool loop = true;

            while (loop)
            {
                Console.WriteLine("\nSelect your choice....\n 1. Add New Entry Customer Order. \n 0.Exit");
                var ip = Convert.ToUInt32(Console.ReadLine());

                switch (ip)
                {
                    case 1:
                        var det = GetInput();
                        custorder.Add(det);
                        break;

                    case 0:
                        loop = false;
                        break;

                    default:
                        Console.WriteLine("Enter Valid Choice..");
                        break;
                }
            }

            DisplayuByCityReport(custorder);

            Console.ReadKey();

        }

        private static void DisplayuByCityReport(List<CustOrder> custorders)
        {
            var filter = (from custorder in custorders
                          group custorder by custorder.disapatchcity into count
                          select new { key = count.Key, c = count.Count() }).ToList();

            var data = filter;

            Console.WriteLine("Dispatch City\tNo Of Orders\tTotal order Value");

            foreach (var item in data)
            {
                Console.WriteLine($"{item.key}\t{item.c}\t{item.c}");
            }
        }

        static CustOrder GetInput()
        {
            CustOrder data = new CustOrder();
            Console.WriteLine();
            Console.WriteLine("Enter Order ID : ");
            data.orderid = Convert.ToInt32(Console.ReadLine());

            Console.WriteLine("Enter Cust ID : ");
            data.custid = Convert.ToInt32(Console.ReadLine());

            Console.WriteLine("Enter Order Dispatch City : ");
            data.disapatchcity = Console.ReadLine();

            Console.WriteLine("Enter Order Amount : ");
            data.orderamount = Convert.ToDouble(Console.ReadLine());
            Console.WriteLine();
            return data;
        }
    }
}
